package ro.teamnet.zerotohero.oop.graphicshape;

/**
 * Created by Andreea.Puscasu on 7/4/2017.
 */
public class Persoana {
    private int varsta;

    public Persoana(int varsta){
        this.varsta =  varsta;
    }

    public int getVarsta() {
        return varsta;
    }
}

