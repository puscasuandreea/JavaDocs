package ro.teamnet.zerotohero.oop.graphicshape;

/**
 * Created by Andreea.Puscasu on 7/4/2017.
 */
public abstract class AbstractShape {

     double area(){
        return 2.0;
    }
}
