package exceptii;

/**
 * Created by Andreea.Puscasu on 7/4/2017.
 */
public class TryFinally {
    public static void main(String[] args) {

        try{
            System.out.println("OOO");

        }finally {
            System.out.println("Afiseaza!");
        }
    }
}