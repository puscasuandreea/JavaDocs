package exceptii;

/**
 * Created by Andreea.Puscasu on 7/4/2017.
 */
public class MyException  extends Exception {

        public MyException() {
            super("Aceasta este o exceptie Checked");
        }

}

